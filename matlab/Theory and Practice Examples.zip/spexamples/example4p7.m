% ----- example 4.7 Posterior probabilities for models
% load the Anselin data set
load anselin.data;
y = anselin(:,1);
nobs = length(y);
x = [ones(nobs,1) anselin(:,2:3)];
[junk nvar] = size(x);
east = anselin(:,4);
north = anselin(:,5);
ndraw = 550; nomit = 50; % estimate all three models
prior.ptype = 'contiguity';
prior.rval = 4; prior.dval = 0.5;
res1 = bgwr(y,x,east,north,ndraw,nomit,prior);
prior2.ptype = 'concentric';
prior2.ctr = 20; prior2.rval = 4; prior2.dval = 0.5;
res2 = bgwr(y,x,east,north,ndraw,nomit,prior2);
prior3.ptype = 'distance';
prior3.rval = 4; prior3.dval = 0.5;
res3 = bgwr(y,x,east,north,ndraw,nomit,prior3);
prior4.ptype = 'distance';
prior4.rval = 4; prior4.dval = 1000;
res4 = bgwr(y,x,east,north,ndraw,nomit,prior4);

% compute posterior model probabilities
nmodels = 4;
postprob = zeros(nobs,nmodels);
logpost = zeros(nobs,nmodels);
logpost(:,1) = res1.logpost;
logpost(:,2) = res2.logpost;
logpost(:,3) = res3.logpost;
logpost(:,4) = res4.logpost;
postsum = sum(logpost');
for j=1:nmodels
        postprob(:,j) = logpost(:,j)./postsum';
end;

% compute posterior means for beta
beta = zeros(nobs,nvar*nmodels);
b1 = res1.bdraw(:,:,1);  beta(:,1) = mean(b1)';
b2 = res1.bdraw(:,:,2);  beta(:,2) = mean(b2)';
b3 = res1.bdraw(:,:,3);  beta(:,3) = mean(b3)';
c1 = res2.bdraw(:,:,1);  beta(:,4) = mean(c1)';
c2 = res2.bdraw(:,:,2);  beta(:,5) = mean(c2)';
c3 = res2.bdraw(:,:,3);  beta(:,6) = mean(c3)';
d1 = res3.bdraw(:,:,1);  beta(:,7) = mean(d1)';
d2 = res3.bdraw(:,:,2);  beta(:,8) = mean(d2)';
d3 = res3.bdraw(:,:,3);  beta(:,9) = mean(d3)';
e1 = res4.bdraw(:,:,1);  beta(:,10) = mean(e1)';
e2 = res4.bdraw(:,:,2);  beta(:,11) = mean(e2)';
e3 = res4.bdraw(:,:,3);  beta(:,12) = mean(e3)';

tt=1:nobs;
plot(tt,postprob(:,1),'ok',tt,postprob(:,2),'*k',tt,postprob(:,3),'+k',tt,postprob(:,4),'-');
legend('contiguity','concentric','distance','diffuse');
%title('posterior probabilties');
xlabel('observations');
ylabel('probabilities');     
pause;

subplot(3,1,1),
plot(tt,beta(:,1),'-k',tt,beta(:,4),'--k',tt,beta(:,7),'-.',tt,beta(:,10),'+');
%legend('contiguity','concentric','distance','diffuse');
xlabel('b1 parameter, + = diffuse, - = contiguity, -- = concentric -. = distance');
subplot(3,1,2),
plot(tt,beta(:,2),'-k',tt,beta(:,5),'--k',tt,beta(:,8),'-.',tt,beta(:,11),'+');
xlabel('b2 parameter + = diffuse, - = contiguity, -- = concentric -. = distance');
subplot(3,1,3),
plot(tt,beta(:,3),'-k',tt,beta(:,6),'--k',tt,beta(:,9),'-.',tt,beta(:,12),'+');
xlabel('b3 parameter + = diffuse, - = contiguity, -- = concentric -. = distance');

% produce a Bayesian model averaging set of estimates
bavg = zeros(nobs,nvar);
cnt = 1;
for j=1:nmodels
bavg = bavg + matmul(postprob(:,j),beta(:,cnt:cnt+nvar-1));
cnt = cnt+nvar;
end;
ttp = tt';
b1out = [ttp bavg(:,1) beta(:,1) beta(:,4) beta(:,7) beta(:,10)];
in.fmt = strvcat('%4d','%8.2f','%8.2f','%8.2f','%8.2f','%8.2f');
in.cnames = strvcat('Obs','average','contiguity','concentric','distance','diffuse');
fprintf(1,'constant term parameter \n');
mprint(b1out,in);

b2out = [ttp bavg(:,2) beta(:,2) beta(:,5) beta(:,8) beta(:,11)];
in.fmt = strvcat('%4d','%8.2f','%8.2f','%8.2f','%8.2f','%8.2f');
in.cnames = strvcat('Obs','average','contiguity','concentric','distance','diffuse');
fprintf(1,'household income parameter \n');
mprint(b2out,in);

b3out = [ttp bavg(:,3) beta(:,3) beta(:,6) beta(:,9) beta(:,12)];
in.fmt = strvcat('%4d','%8.3f','%8.3f','%8.3f','%8.3f','%8.3f');
in.cnames = strvcat('Obs','average','contiguity','concentric','distance','diffuse');
fprintf(1,'house value parameter \n');
mprint(b3out,in);

