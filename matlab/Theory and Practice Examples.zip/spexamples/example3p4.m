% ----- Example 3.4 Using far_g with a large data set
load elect.dat;             % load data on votes in 3,107 counties
y =  (elect(:,7)./elect(:,8));    % convert to per capita variables
ydev = y - mean(y);
clear elect;                % conserve on RAM memory
load ford.dat; % 1st order contiguity matrix stored in sparse matrix form
ii = ford(:,1); jj = ford(:,2); ss = ford(:,3);
n = 3107;
clear ford; % clear ford matrix to save RAM memory
W = sparse(ii,jj,ss,n,n); 
clear ii; clear jj; clear ss; % conserve on RAM memory
res = far(ydev,W,0,1); prt(res);
prior.rval = 4; prior.rmin = 0; prior.rmax = 1;
ndraw = 1100; nomit = 100;
res = far_g(ydev,W,ndraw,nomit,prior);
prt(res);

pltdens(res.pdraw,0.01,0,1);
pause;

plot(res.vmean);
xlabel('Observations');
ylabel('V_i estimates');
