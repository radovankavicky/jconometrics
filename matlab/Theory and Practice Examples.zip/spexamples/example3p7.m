% ----- Example 3.7 Robust Boston model estimation
load boston.raw; % Harrison-Rubinfeld data
load latittude.data; load longitude.data;
[W1 W W3] = xy2cont(latittude,longitude); % create W-matrix
[n k] = size(boston);y = boston(:,k);  % median house values
x = [ones(n,1) boston(:,1:k-1)];       % other variables
vnames = strvcat('hprice','crime','zoning','industry','charlesr', ...
         'noxsq','rooms2','houseage','distance','access','taxrate', ...
         'pupil/teacher','blackpop','lowclass');
ys = studentize(log(y)); xs = studentize(x(:,2:k));
rmin = 0; rmax = 1;
tic; res1 = sar(ys,xs,W,rmin,rmax); prt(res1,vnames); toc;
prior.rmin = 0; prior.rmax = 1;
prior.rval = 4;
ndraw = 1100; nomit=100;
tic; resg1 = sar_g(ys,xs,W,ndraw,nomit,prior); 
prt(resg1,vnames); toc;
tic; res2 = sem(ys,xs,W,rmin,rmax); prt(res2,vnames); toc;
tic; resg2 = sem_g(ys,xs,W,ndraw,nomit,prior); 
prt(resg2,vnames); toc;
tic; res3 = sac(ys,xs,W,W);         prt(res3,vnames); toc;
tic; resg3 = sac_g(ys,xs,W,W,ndraw,nomit,prior); 
prt(resg3,vnames); toc;
