% Example 1.1 Anselin's Columbus neighborhood spatial data sample
% 
load Wmat.data; load anselin.data; % load the data;
y = anselin(:,1); W = Wmat;
nobs = length(y);
% construct an explanatory variables matrix
x = [ones(nobs,1) anselin(:,2) anselin(:,3)];
% set up variable names
vnames = strvcat('Crime','constant','income','house value');
result = sar(y,x,W); % estimate spatial autoregressive model
prt(result,vnames);  % print results
result2 = ols(y,x);  % compare to least-squares estimates
prt(result,vnames);  % print results

