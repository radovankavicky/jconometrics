% ----- Example 2.6 Least-squares bias
%       demonstrated with Ohio county data base
load ohio1.dat; % 88 counties (observations)
% 10 columns
% col1  area in square miles 
% col2  total population 
% col3  population per square mile
% col4  nonwhite population 
% col5  nonwhite as a percentage of population 
% col6  number of hospitals 
% col7  total crimes 
% col8  crime rate per capita 
% col9  population that are high school graduates 
% col10 population that are college graduates 
load ohio2.dat; % 88 counties
% 10 columns
% col1   income per capita 
% col2   average family income 
% col3   families in poverty 
% col4   percent of families in poverty 
% col5   total number of households 
% col6   average housing value 
% col7   unemployment rate 
% col8   total manufacturing employment 
% col9   manufacturing employment as a percent of total 
% col10  total employment 
load ohio.xy; % latittude-longitude coordinates of county centroids
[junk W junk2] = xy2cont(ohio(:,1),ohio(:,2)); % make W-matrix
y = log(ohio2(:,6)); n = length(y);
xlog = ([ohio1(:,3) ohio2(:,5)./ohio1(:,2) ohio2(:,7)]);
x = [ones(n,1) xlog ];
vnames = strvcat('hvalue','constant','popsqm','housedensity','urate');
res = ols(y,x);   prt(res,vnames);
res = sar(y,x,W); prt(res,vnames);

