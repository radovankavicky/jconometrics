% ----- Example 3.4 Using the gwr() function
% load the Anselin data set
load anselin.dat;
y = anselin(:,1);
nobs = length(y);
x = [ones(nobs,1) anselin(:,2:3)];
north = anselin(:,4);
east = anselin(:,5);
vnames = strvcat('crime','const','income','hse value');

% y =  dependent variable
% x = a matrix of indepdendent variables
% east holds  x-coordinates
% north holds y-coordinates
% nobs = # of observations
% nvar = # of explanatory variables
info.dtype = 'gaussian';
result1 = gwr(y,x,east,north,info);

info.dtype = 'exponential';
result2 = gwr(y,x,east,north,info);

tt=1:nobs;
subplot(3,1,1),
plot(tt,result1.beta(:,1),tt,result2.beta(:,1),'--');
legend('Gaussian','Exponential');
ylabel('Constant term');
subplot(3,1,2),
plot(tt,result1.beta(:,2),tt,result2.beta(:,2),'--');
legend('Gaussian','Exponential');
ylabel('Household income');
subplot(3,1,3),
plot(tt,result1.beta(:,3),tt,result2.beta(:,3),'--');
legend('Gaussian','Exponential');
ylabel('House value');
