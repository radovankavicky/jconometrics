% ----- Example 2.4 Using the far() function
%       with very large data set

load elect.dat;             % load data on votes
y = elect(:,7)./elect(:,8); % proportion of voters casting votes
ydev = y - mean(y);         % deviations from the means form 
clear y;     % conserve on RAM memory
clear elect; % conserve on RAM memory
load ford.dat; % 1st order contiguity matrix stored in sparse matrix form
ii = ford(:,1); jj = ford(:,2); ss = ford(:,3);
n = 3107;
clear ford; % clear ford matrix to save RAM memory
W = sparse(ii,jj,ss,n,n); 
clear ii; clear jj; clear ss; % conserve on RAM memory
to = clock;
res = far(ydev,W);
etime(clock,to)
prt(res);
