% ----- Example 4.7 Robust Boston model BGWR estimation
load boston.raw; % Harrison-Rubinfeld data
load latittude.data; load longitude.data;
[n k] = size(boston);y = boston(:,k);  % median house values
x = boston(:,1:k-1);       % other variables
vnames = strvcat('crime','zoning','industry','charlesr', ...
         'noxsq','rooms2','houseage','distance','access','taxrate', ...
         'pupil/teacher','blackpop','lowclass');
ys = studentize(y); xs = studentize(x);
clear x; clear y; clear boston;
ndraw = 100; nomit = 25;
prior.ptype = 'distance'; 
prior.rval = 4; 
prior.dval = 10;
res3 = bbgwr(ys,xs,latittude,longitude,ndraw,nomit,prior);
bmean = zeros(k-1,n);
for i=1:k-1;
bmean(i,:) = mean(res3.bdraw(:,:,i));
end;

save res3;
save bmean;

for i=1:k-1
nobs = length(latittude);
tt=1:nobs;
plot(tt,bmean(i,:),'--b');
title(vnames(i,:));
pause;
end;
