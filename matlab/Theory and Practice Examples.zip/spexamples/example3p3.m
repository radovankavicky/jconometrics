% ----- Example 3.3 Using the far_g function

load wmat.dat; % standardized 1st-order spatial weight matrix
W = wmat;      % from the Columbus neighborhood data set
[n junk] = size(W);
IN = eye(n); 
randn('seed',1010123);
rho = 0.75;  % true value of rho
y = inv(IN-rho*W)*randn(n,1)*5; 
ydev = y - mean(y);
vnames = strvcat('y-simulated','y-spatial lag');

% do maximum likelihood for comparison 
rmin = 0; rmax = 1;
resml = far(ydev,W,rmin,rmax);
prt(resml,vnames);

ndraw = 1100;
nomit = 100;
prior.rval = 30; % homoscedastic model, 
                 % diffuse prior (the default)
prior.rmin = 0; prior.rmax = 1;
% call Gibbs sampling function
result = far_g(ydev,W,ndraw,nomit,prior);
prt(result,vnames);

prior.rval = 4; % heteroscedastic model, 
                % diffuse prior (the default)
% add outliers to the generated data

ydev(20,1) =  ydev(20,1)*10;
ydev(39,1) =  ydev(39,1)*10;
plot(ydev);

resml2 = far(ydev,W);
prt(resml2,vnames);

% call Gibbs sampling function
result2 = far_g(ydev,W,ndraw,nomit,prior);
prt(result2,vnames);

% plot the vi-estimates
plot(result2.vmean);
xlabel('Observations');
ylabel('mean of V_i draws');

