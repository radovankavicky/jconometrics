% ----- Example 2.1 Using the far() function
load wmat.dat;    % standardized 1st-order contiguity matrix
load anselin.dat; % load Anselin (1988) Columbus neighborhood crime data
y = anselin(:,1); 
ydev = y - mean(y);
W = wmat;
vnames = strvcat('crime','rho');
res = far(ydev,W);  % do 1st-order spatial autoregression 
prt(res,vnames);    % print the output
plt(res,vnames);    % plot actual vs predicted and residuals