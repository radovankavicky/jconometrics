% Example 1.3 Casetti's distance expansion estimates
% Anselin's Columbus neighborhood spatial data sample
 
load anselin.data; % load the data;
y = anselin(:,1);
nobs = length(y);
% construct an explanatory variables matrix
x = [ones(nobs,1) anselin(:,2) anselin(:,3)];
xc = anselin(:,4);
yc = anselin(:,5);
% set up variable names
vnames = strvcat('Crime','constant','income','house value');

% do Casetti regression using distance expansion
option.exp = 1;
option.ctr = 32;
res = casetti(y,x,xc,yc,option);

% print the output
prt(res,vnames);
plt(res,vnames);

% compute inverse distance from central point
ctr = option.ctr;
xi = xc(ctr);
yi = yc(ctr);

% calculate distance weighting function
d = sqrt((xc-xi).*(xc-xi) + (yc-yi).*(yc-yi));
d(ctr,1) = 1; % norm on central area
dvec = ones(nobs,1)./d;

[dsort dind] = sort(dvec);
betas = res.beta(dind,:)

subplot(3,1,1),
plot(betas(:,1));
xlabel('Distance from central city');
ylabel('Constant term');
subplot(3,1,2),
plot(betas(:,2));
xlabel('Distance from central city');
ylabel('household income');
subplot(3,1,3),
plot(betas(:,3));
xlabel('Distance from central city');
ylabel('house value');
