% ----- Example 3.6 An outlier example
load anselin.dat; load wmat.dat;
load anselin.dat; % load Anselin (1988) Columbus neighborhood crime data
x = [anselin(:,2:3)];
[n k] = size(x); x = [ones(n,1) x];
W = wmat; IN = eye(n);
rho = 0.5;  % true value of rho
b = ones(k+1,1);
Winv = inv(IN-rho*W);
y = Winv*x*b + Winv*randn(n,1); 
vnames = strvcat('y-simulated','constant','income','house value');
% insert outliers
y(10,1) = y(10,1)*2;
y(40,1) = y(40,1)*2;
plot(y);
pause;
% do maximum likelihood for comparison          
resml = sar(y,x,W);
prt(resml,vnames);

ndraw = 1100;
nomit = 100;
prior.rval = 100; % homoscedastic model, 

resg = sar_g(y,x,W,ndraw,nomit,prior);
prt(resg,vnames);

prior.rval = 3; % heteroscedastic model, 
resg2 = sar_g(y,x,W,ndraw,nomit,prior);
prt(resg2,vnames);

% plot the vi-estimates
plot(resg2.vmean);
xlabel('Observations');
ylabel('mean of V_i draws');

