% ----- Example 2.11 Least-squares on the Boston dataset
load boston.raw; % Harrison-Rubinfeld data
[n k] = size(boston);y = boston(:,k);  % median house values
x = [ones(n,1) boston(:,1:k-1)];       % other variables
[n k] = size(x); [ys yi] = sort(y);    % ascending sort by house values
xs = x(yi,:);                          % sort other variables
vnames = strvcat('hprice','constant','crime','zoning','industry','charlesr', ...
         'noxsq','rooms2','houseage','distance','access','taxrate', ...
         'pupil/teacher','blackpop','lowclass');
res = ols(ys,xs); prt(res,vnames);
ystud = studentize(ys);
xstud = studentize(xs(:,2:k));
res2 = ols(ystud,xstud);
vnames2 = strvcat('hprice','crime','zoning','industry','charlesr', ...
         'noxsq','rooms2','houseage','distance','access','taxrate', ...
         'pupil/teacher','blackpop','lowclass');
prt(res2,vnames2);
% sort actual and predicted by housing values from low to high
yhat = res2.yhat; [ysort yi] = sort(ystud); yhats = yhat(yi,1);
tt=1:n; % plot actual vs. predicted
plot(tt,ysort,'ok',tt,yhats,'+k');
ylabel('housing values');
xlabel('census tract observations');