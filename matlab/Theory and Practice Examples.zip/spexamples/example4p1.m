% ----- Example 4.1 Using casetti() function
% load Anselin (1988) Columbus neighborhood crime data
load anselin.dat;
y = anselin(:,1); n = length(y); x = [ones(n,1) anselin(:,2:3)];
% Anselin (1988) x-y coordinates
xc0 = anselin(:,4); yc0 = anselin(:,5);
vnames = strvcat('crime','const','income','house value');
% do Casetti regression using x-y expansion (default)
res1 = casetti(y,x,xc0,yc0);
prt(res1,vnames); % print the output
plt(res1,vnames); % graph the output
pause;
%  Casetti regression using distance expansion from
% a central observation #20 
option.exp = 1; option.ctr = 20;
res2 = casetti(y,x,xc0,yc0,option);
prt(res2,vnames); % print the output
plt(res2,vnames); % graph the output

