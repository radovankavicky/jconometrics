% ----- Example 4.7a Boston model GWR estimation
load boston.raw; % Harrison-Rubinfeld data
load latittude.data; load longitude.data;
[n k] = size(boston);y = boston(:,k);  % median house values
x = boston(:,1:k-1);       % other variables
vnames = strvcat('hprice','crime','zoning','industry','charlesr', ...
         'noxsq','rooms2','houseage','distance','access','taxrate', ...
         'pupil/teacher','blackpop','lowclass');
ys = studentize(y); xs = studentize(x);
clear x; clear y; clear boston;
info.dtype = 'exponential';
res1 = gwr(ys,xs,latittude,longitude,info);
save res1;
