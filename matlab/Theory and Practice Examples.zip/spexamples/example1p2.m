% Produces the Figure 1.2 graph

% Data are sorted by distance from central city

load housexy.dat; % census tract x-y location coordinates
% col1 = census tract #  
% (census tract 28 = central business district)
% col2 = x-coord
% col3 = y-coord
% These match the order in house.dat

east  = housexy(:,2);
north = housexy(:,3);

load house.dat; % average house values
                % for 98 census tracts
% 14 columns

% col1 = census tract
% col2 = neighborhood
%        1=improving
%        2=static
%        3=declining
%        4=blighted
% col3 = net lot square foot
% col4 = total square foot living area
% col5 = family room
%        1=vacant lot
%        2=yes
%        3=no
% col6 = rec room
%        1=vacant lot
%        2=type1
%        3=type2
%        4=type3
%        5=type4
%        6=no rec room
% col7 = air conditioning
%        1=vacant lot
%        2=yes
%        3=no
% col8 = baths
%        1=vacant lot
%        2=no plumbing
%        3=water only
%        4=half bath
%        5=1 bath
%        6=1+1half 
%        7=1+2half
%        8=2
%        9=2+1half
%        10=2+2half
%        11=3
%        12=3+1half
%        13=3+2half
%        14=4
%        15=5
%        16=6
%        17= >6 baths
% col9 = relative condition
%        1=vacant lot
%        2=excellent
%        3=very good
%        4=good
%        5=average
%        6=fair
%        7=poor
%        8=very poor
%        9=Us
%        10=sv
% col10 = garage condition
%        1=vacant lot
%        2=excellent
%        3=very good
%        4=good
%        5=average
%        6=fair
%        7=poor
%        8=very poor
%        9=Us
%        10=sv
%        11=no garage
% col11 = value of land
% col12 = value of building
% col13 = house value (y-variable we would like to predict)
% col14 = year built

yearbuilt = house(:,14);
[easto northo] = normxy(east,north);

emin = min(easto); nmin = min(northo);
emax = max(easto); nmax = max(northo);
scalex = (emax-emin)/100;
scaley = (nmax-nmin)/100;
ei = emin:scalex:emax; ni = nmin:scaley:nmax;
[xi yi] = meshgrid(ei,ni);
[easti northi yeari] = griddata(easto,northo,yearbuilt,xi,yi,'nearest');

surf(easti,northi,yeari);
