% ----- Example 2.9 Using the sac function
load Wmat.dat;    % standardized 1st-order contiguity matrix
load anselin.dat; % load Anselin (1988) Columbus neighborhood crime data
y = anselin(:,1); nobs = length(y);
x = [ones(nobs,1) anselin(:,2:3)];
W = Wmat;
vnames = strvcat('crime','const','income','house value');
W2 = W'*W;
subplot(2,1,1), spy(W);
xlabel('First-order contiguity structure');
subplot(2,1,2), spy(W2);
xlabel('contiguity structure of W2');
res1 = sac(y,x,W2,W);% general spatial model W2,W
prt(res1,vnames);    % print the output
res2 = sac(y,x,W,W2);% general spatial model W,W2
prt(res2,vnames);    % print the output
res3 = sac(y,x,W,W); % general spatial model W,W2
prt(res3,vnames);    % print the output

