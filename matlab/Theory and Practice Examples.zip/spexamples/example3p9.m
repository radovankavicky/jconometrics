% ----- Example 3.9 The probability of negative lambda
load boston.raw; % Harrison-Rubinfeld data
load latittude.data; load longitude.data;
[W1 W W3] = xy2cont(latittude,longitude); % create W-matrix
[n k] = size(boston);y = boston(:,k);  % median house values
x = [boston(:,1:k-1)];       % other variables
vnames = strvcat('hprice','crime','zoning','industry','charlesr', ...
         'noxsq','rooms2','houseage','distance','access','taxrate', ...
         'pupil/teacher','blackpop','lowclass');
ys = studentize(log(y)); xs = studentize(x);
prior.rval = 4; ndraw = 2100; nomit=100;
prior.lmin = 0; prior.lmax = 1;
resg3 = sac_g(ys,xs,W,W,ndraw,nomit,prior); 
prt(resg3,vnames); 
% find the number of lambda draws < 0
nlam = find(resg3.ldraw < 0);
fprintf(1,'The # of negative lambda values is: %5d \n',length(nlam));
fprintf(1,'Probability lambda < 0 is: %6.2f \n',length(nlam)/(ndraw-nomit));
