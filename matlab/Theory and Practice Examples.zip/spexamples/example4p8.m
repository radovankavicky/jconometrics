% ----- Example 4.7 Robust Boston model BGWR estimation
load boston.raw; % Harrison-Rubinfeld data
load latittude.data; load longitude.data;
latt = latittude(357:488,1); longi = longitude(357:488,1);
[n k] = size(boston(357:488,:));
y = boston(357:488,k);  % median house values
x = [boston(357:488,1:k-1)];       % other variables
% pitch industry, charlesr, distance, taxrate, pupil/teacher
% which are the same for Boston
% these are variables 3,4,8,10,11,12
xnew = [x(:,1) x(:,4:8) x(:,12:13)];
xs = studentize(xnew);
vnames = strvcat('hprice','crime','charlesr', ...
         'noxsq','rooms2','houseage','distance', ...
         'blackpop','lowclass');
ys = studentize(y);
prt(ols(ys,xs),vnames);

clear boston;  clear y; clear x;
info.dtype = 'exponential';
res1b = gwr(ys,xs,latt,longi);
nvar = length(vnames)-1;
% for i=1:nvar
nobs = length(res1b.beta);
tt=1:nobs;
% plot(tt,res1b.beta(:,i),'-r');
% title(vnames(i+1,:));
% pause;
% end;

ndraw = 150; nomit = 50;
prior.ptype = 'distance'; 
prior.rval = 4;
%prior.dval = 1000000;

res2b = bbgwr(ys,xs,latt,longi,ndraw,nomit,prior);


for i=1:nvar
bgwrb = mean(res2b.bdraw(:,:,i));
nobs = length(bgwrb);
plot(tt,res1b.beta(:,i),'-b',tt,bgwrb,'--r');
title(vnames(i+1,:));
pause;
end;

plot(res2b.vmean);
title('vi estimates');
