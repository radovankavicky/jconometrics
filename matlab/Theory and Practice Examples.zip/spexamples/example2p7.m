% ----- Example 2.6 Testing for spatial correlation
load wmat.dat;    % standardized 1st-order contiguity matrix
load anselin.dat; % load Anselin (1988) Columbus neighborhood crime data
y = anselin(:,1); nobs = length(y);
x = [ones(nobs,1) anselin(:,2:3)];
W = wmat;
vnames = strvcat('crime','const','income','house value');
res1 = moran(y,x,W);
prt(res1);
res2 = lmerror(y,x,W);
prt(res2);
res3 = lratios(y,x,W);
prt(res3);
res4 = walds(y,x,W);
prt(res4);
res5 = lmsar(y,x,W,W);
prt(res5);
res = sem(y,x,W);% do 1st-order spatial autoregression 
prt(res,vnames); % print the output