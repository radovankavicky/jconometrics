% ----- Example 3.5 Using the bgwr() function
% load the Anselin data set
load anselin.data;
y = anselin(:,1); nobs = length(y);
x = [ones(nobs,1) anselin(:,2:3)]; [junk nvar] = size(x);
east = anselin(:,4); north = anselin(:,5);
ndraw = 550; nomit = 50;
prior.ptype = 'distance'; prior.rval = 4; 
prior.s = 50;
prior.t = 2;
result = bgwr(y,x,east,north,ndraw,nomit,prior);
vnames = strvcat('crime','constant','income','hvalue');
prt(result,vnames);
info.dtype = 'exponential';
result2 = gwr(y,x,east,north,info);
% compare gwr and bgwr estimates 
b1 = result.bdraw(:,:,1); b1mean = mean(b1);
b2 = result.bdraw(:,:,2); b2mean = mean(b2);
b3 = result.bdraw(:,:,3); b3mean = mean(b3);
betagwr = result2.beta;
tt=1:nobs;
plot(tt,betagwr(:,1),'-r',tt,b1mean,'--b');
legend('gwr','bgwr');
title('b1 parameter');
pause;
plot(tt,betagwr(:,2),'-r',tt,b2mean,'--b');
legend('gwr','bgwr');
title('b2 parameter');
pause;
plot(tt,betagwr(:,3),'-r',tt,b3mean,'--b');
legend('gwr','bgwr');
title('b3 parameter');
pause;
% plot sige draws 
plot(result.sdraw);
title('sige draws');
pause;
% plot mean of vi draws across observations
plot(tt,mean(result.vdraw));
title('vi means');
pause;

tt=1:nobs;
subplot(3,1,1),
plot(tt,betagwr(:,1),'-k',tt,b1mean,'--k');
legend('gwr','bgwr');
ylabel('b1 parameter');
subplot(3,1,2),
plot(tt,betagwr(:,2),'-k',tt,b2mean,'--k');
%legend('gwr','bgwr');
ylabel('b2 parameter');
subplot(3,1,3),
plot(tt,betagwr(:,3),'-k',tt,b3mean,'--k');
%legend('gwr','bgwr');
ylabel('b3 parameter');
pause;


