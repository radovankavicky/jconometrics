% ----- Example 3.5 Using the sem_g function
load wmat.dat;    % standardized 1st-order contiguity matrix
load anselin.dat; % load Anselin (1988) Columbus neighborhood crime data
y = anselin(:,1);  n = length(y);
x = [ones(n,1) anselin(:,2:3)];
W = wmat; IN = eye(n);
vnames = strvcat('crime','const','income','house value');
tt = ones(n,1); tt(25:n,1) = [1:25]';
rvec = 0.1:.1:.9; b = ones(3,1); 
nr = length(rvec);
results = zeros(nr,6);
ndraw = 600; nomit = 100;
prior.rval = 30; 
%lmin = 0; lmax = 1;
bsave = zeros(nr,6);
for i=1:nr
rho = rvec(i);
u = (inv(IN-rho*W))*randn(n,1);
y =  x*b  + u;
% do maximum likelihood for comparison   
resml = sem(y,x,W);
prt(resml);
results(i,1) = resml.lam;
results(i,2) = resml.tstat(4,1);
bsave(i,1:3) = resml.beta';
% call Gibbs sampling function
result = sem_g(y,x,W,ndraw,nomit,prior);
prt(result);
results(i,3) = mean(result.pdraw);
results(i,4) = results(i,3)/std(result.pdraw);
results(i,5) = result.time;
results(i,6) = result.accept;
bsave(i,4:6) = mean(result.bdraw);
end;

in.rnames = strvcat('True lam','0.1','0.2','0.3', ...
'0.4','0.5','0.6','0.7','0.8','0.9');
in.cnames = strvcat('ML lam','lam t','Gibbs lam','lam t', ...
 'time','accept');
mprint(results,in);

in2.cnames = strvcat('b1 ML','b2 ML','b3 ML','b1 Gibbs','b2 Gibbs','b3 Gibbs');
mprint(bsave,in2);
