% ----- Example 3.7 Robust Boston model estimation
load boston.raw; % Harrison-Rubinfeld data
load latittude.data; load longitude.data;
[W1 W W3] = xy2cont(latittude,longitude); % create W-matrix
[n k] = size(boston);y = boston(:,k);  % median house values
x = [ones(n,1) boston(:,1:k-1)];       % other variables
vnames = strvcat('hprice','crime','zoning','industry','charlesr', ...
         'noxsq','rooms2','houseage','distance','access','taxrate', ...
         'pupil/teacher','blackpop','lowclass');
ys = studentize(log(y)); xs = studentize(x(:,2:k));
prior.lmin = 0; prior.lmax = 1;
prior.rmin = 0; prior.rmax = 1;
prior.rval = 4;
ndraw = 1100; nomit=100;
tic; resg3 = sac_g(ys,xs,W,W,ndraw,nomit,prior); 
prt(resg3,vnames); toc;
