% ----- Example 2.8 Using the sem() function on a large data set
load elect.dat;             % load data on votes in 3,107 counties
y =  (elect(:,7)./elect(:,8));    % convert to per capita variables
x1 = log(elect(:,9)./elect(:,8)); % education
x2 = log(elect(:,10)./elect(:,8));% homeownership
x3 = log(elect(:,11)./elect(:,8));% income
n = length(y); x = [ones(n,1) x1 x2 x3];
clear x1; clear x2; clear x3;
clear elect;                % conserve on RAM memory
load ford.dat; % 1st order contiguity matrix stored in sparse matrix form
ii = ford(:,1); jj = ford(:,2); ss = ford(:,3);
n = 3107;
clear ford; % clear ford matrix to save RAM memory
W = sparse(ii,jj,ss,n,n); 
clear ii; clear jj; clear ss; % conserve on RAM memory
vnames = strvcat('voters','const','educ','homeowners','income');
to = clock;
res = sem(y,x,W);
etime(clock,to)
prt(res,vnames);

