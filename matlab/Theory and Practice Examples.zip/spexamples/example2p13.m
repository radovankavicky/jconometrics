% ----- Example 2.13 Spatial autoregressive model estimation
load boston.raw; % Harrison-Rubinfeld data
load latittude.data; load longitude.data;
[W1 W W3] = xy2cont(latittude,longitude); % create W-matrix
[n k] = size(boston);y = boston(:,k);  % median house values
x = [ones(n,1) boston(:,1:k-1)];       % other variables
vnames = strvcat('hprice','crime','zoning','industry','charlesr', ...
         'noxsq','rooms2','houseage','distance','access','taxrate', ...
         'pupil/teacher','blackpop','lowclass');
ys = studentize(log(y)); xs = studentize(x(:,2:k));
rmin = 0; rmax = 1;
tic; res1 = sar(ys,xs,W,rmin,rmax); prt(res1,vnames); toc;
tic; res2 = sem(ys,xs,W,rmin,rmax); prt(res2,vnames); toc;
tic; res3 = sac(ys,xs,W,W);         prt(res3,vnames); toc;


