% ----- Example 2.5 Using xy2cont()

load anselin.data;  % Columbus neighborhood crime
xc = anselin(:,5);  % longitude coordinate
yc = anselin(:,4);  % latittude coordinate
load wmat.data;     % load standardized contiguity matrix
% create contiguity matrix from x-y coordinates
[W1 W2 W3] = xy2cont(xc,yc);
% graphically compare the two
spy(W2,'ok'); hold on; spy(wmat,'+k');
legend('generated','actual');
