% ----- Example 2.4 Using the sar() function
%       with very large data set
load elect.dat;             % load data on votes
y =  (elect(:,7)./elect(:,8));
x1 = log(elect(:,9)./elect(:,8));
x2 = log(elect(:,10)./elect(:,8));
x3 = log(elect(:,11)./elect(:,8));
n = length(y); x = [ones(n,1) x1 x2 x3];
clear x1; clear x2; clear x3;
clear elect;                % conserve on RAM memory
load ford.dat; % 1st order contiguity matrix stored in sparse matrix form
ii = ford(:,1); jj = ford(:,2); ss = ford(:,3);
n = 3107;
clear ford; % clear ford matrix to save RAM memory
W = sparse(ii,jj,ss,n,n); 
clear ii; clear jj; clear ss; % conserve on RAM memory
vnames = strvcat('voters','const','educ','homeowners','income');
to = clock;
res = sar(y,x,W);
etime(clock,to)
prt(res,vnames);
