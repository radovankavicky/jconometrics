% ----- Example 3.2 Using the darp() function
% load Anselin (1988) Columbus neighborhood crime data
load anselin.dat; y = anselin(:,1); n = length(y);
x = [ones(n,1) anselin(:,2:3)];
xc = anselin(:,4); yc = anselin(:,5); % Anselin  x-y coordinates
vnames = strvcat('crime','const','income','hse value');
% do Casetti darp using x-y expansion
res1 = darp(y,x,xc,yc);
prt(res1,vnames); % print the output
plt(res1,vnames); % plot the output
pause;
% do Casetti darp using distance expansion from observation #32
option.exp = 1; option.ctr = 20;
res2 = darp(y,x,xc,yc,option);
prt(res2,vnames); % print the output
plt(res2,vnames); % plot the output
