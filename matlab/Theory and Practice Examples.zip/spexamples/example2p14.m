% ----- Example 2.14 Final model checking
load boston.raw; % Harrison-Rubinfeld data
load latittude.data; load longitude.data;
[W1 W W3] = xy2cont(latittude,longitude); % create W-matrix
[n k] = size(boston);y = boston(:,k);  % median house values
x = [ones(n,1) boston(:,1:k-1)];       % other variables
vnames = strvcat('hprice','crime','zoning','industry','charlesr', ...
         'noxsq','rooms2','houseage','distance','access','taxrate', ...
         'pupil/teacher','blackpop','lowclass');
ys = studentize(log(y)); xs = studentize(x(:,2:k));
rmin = 0; rmax = 1; 
W2 = W*W;
res = sac(ys,xs,W,W2); prt(res,vnames); 
res2 = sac(ys,xs,W,W); 
resid = res2.resid; % recover SAC residuals
prt(far(resid,W2,rmin,rmax));
