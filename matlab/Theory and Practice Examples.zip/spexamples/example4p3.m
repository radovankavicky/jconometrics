% ----- Example 3.3 Using the darp() over space
% load Anselin (1988) Columbus neighborhood crime data
load anselin.dat; y = anselin(:,1); n = length(y);
x = [ones(n,1) anselin(:,2:3)];
xc = anselin(:,4); yc = anselin(:,5); % Anselin  x-y coordinates
vnames = strvcat('crime','const','income','hse value');
% do Casetti darp using distance expansion from all
% observations in the data sample
option.exp = 1;
output = zeros(n,2);
tic;
for i=1:n % loop over all observations
 option.ctr = i;
res = darp(y,x,xc,yc,option);
output(i,1) = res.gamma(1);
output(i,2) = res.cprob(1);
end;
toc;
in.cnames = strvcat('gamma estimate','marginal probability');
in.rflag = 1;
mprint(output,in)
