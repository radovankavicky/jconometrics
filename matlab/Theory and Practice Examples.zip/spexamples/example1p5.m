% PURPOSE: An example of using sar()
%          Spatial autoregressive model
%
%---------------------------------------------------
% USAGE: sar_d
%---------------------------------------------------

% load Anselin (1988) Columbus neighborhood crime data
load anselin.dat;

y = anselin(:,1);
n = length(y);
x = [ones(n,1) anselin(:,2:3)];

% load Anselin (1988) 1st order contiguity matrix
load wmat.dat; % standardized
W = wmat;

vnames = strvcat('crime','const','income','house value');
          
% do sar regression
res = sar(y,x,W);
prt(res);
% print the output with variable names
prt(res,vnames);

