% Example 1.4 compare casetti distance expansion
% estimates to GWR estimates.

% Anselin's Columbus neighborhood spatial data sample
 
load anselin.data; % load the data;
y = anselin(:,1); 
nobs = length(y);
% construct an explanatory variables matrix
x = [ones(nobs,1) anselin(:,2) anselin(:,3)];
% set up variable names
vnames = strvcat('Crime','constant','income','house value');
xc = anselin(:,4); yc = anselin(:,5);
% do Casetti regression using distance expansion
option.exp = 1;
option.ctr = 32;
ctr = 32;
xc = anselin(:,4);
yc = anselin(:,5);
res1 = casetti(y,x,xc,yc,option);

res2 = gwr_reg(y,x,xc,yc);

% compute inverse distance from central point
xi = xc(ctr);
yi = yc(ctr);
% calculate distance weighting function
d = sqrt((xc-xi).*(xc-xi) + (yc-yi).*(yc-yi));
d(ctr,1) = 1; % norm on central area
dvec = ones(nobs,1)./d;
[dsort dind] = sort(dvec);
betac = res1.beta(dind,:);
betag = res2.beta(dind,:);

tt=1:nobs;

subplot(3,1,1),
plot(tt,betac(:,1),'-k',tt,betag(:,1),'--k');
xlabel('Distance from central city');
ylabel('Constant term');
legend('casetti','gwr');
subplot(3,1,2),
plot(tt,betac(:,2),'-k',tt,betag(:,2),'--k');
xlabel('Distance from central city');
ylabel('household income');
subplot(3,1,3),
plot(tt,betac(:,3),'-k',tt,betag(:,3),'--k');
xlabel('Distance from central city');
ylabel('house value');

